package test;

import java.util.Random;
import java.util.Scanner;

public class Test5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random random = new Random();

        int[] arr = new int[3];
        int s = 0;
        int b = 0;

        for (int i = 0; i < arr.length; i++){
            arr[i] = random.nextInt(9)+1;
        }
        while (true){
            if (arr[0] != arr[1]){
                if (arr[0] != arr[2] && arr[1] != arr[2]){
                    break;
                }
                else {
                    arr[2] = random.nextInt(9)+1;
                }
            }
            else {
                arr[1] = random.nextInt(9)+1;
            }
        }
        for (int i = 0; i < arr.length; i++){
            System.out.println(arr[i] + " ");
        }

        int total = 0;

        while (true){
            int[] user = new int[3];

            System.out.println("1~9까지 중복되지 않게 숫자 입력 : ");

            for (int i = 0; i < user.length; i++){
                user[i] = sc.nextInt();
                if (user[i]<1 || user[i]> 9){

                    System.out.println("다시 입력해주세요");
                    break;
                }
            }



        }






    }
}
